**Build A Monster**

Template code for displaying sprites from a spritesheet Atlas (XML) using Phaser 3.

Uses Kenny Assets "[Monster Builder Pack](https://kenney.nl/assets/monster-builder-pack)" set, with gratitude.
